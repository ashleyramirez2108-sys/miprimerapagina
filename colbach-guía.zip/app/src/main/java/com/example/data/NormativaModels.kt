package com.example.data

enum class AppTab {
    ASISTENTE,
    NORMATIVA,
    GUIA,
}

enum class StudyModality(val label: String, val promptContext: String) {
    TODAS(
        label = "Todas",
        promptContext = "El estudiante no especificó modalidad; si la respuesta varía entre modalidad escolarizada y no escolarizada/en línea, indícalo brevemente."
    ),
    ESCOLARIZADA(
        label = "Escolarizada",
        promptContext = "El estudiante cursa en Modalidad Escolarizada (plantel presencial)."
    ),
    EN_LINEA(
        label = "En Línea / SEA",
        promptContext = "El estudiante consulta sobre Modalidad No Escolarizada / Bachillerato en Línea (Opción Educativa Virtual) o SEA."
    ),
}

data class ChatMessage(
    val id: String,
    val isUser: Boolean,
    val text: String,
    val timestampMillis: Long = System.currentTimeMillis(),
)

enum class NormativaSource(val label: String) {
    ALL("Todo"),
    REGLAMENTO_2025("Reglamento 2025"),
    BACHILLERATO_EN_LINEA_2018("En Línea 2018"),
    GLOSARIO("Glosario"),
}

data class NormativaEntry(
    val id: String,
    val source: NormativaSource,
    val title: String,
    val reference: String,
    val summary: String,
    val details: List<String>,
    val tags: List<String>,
)

data class QuickPrompt(
    val id: String,
    val category: String,
    val question: String,
)

data class GradeCalculationResult(
    val finalGrade: Int?,
    val statusLabel: String,
    val explanation: String,
    val isApproved: Boolean,
    val isWStatus: Boolean,
    val legalReference: String,
)
