package com.example.data

object ColbachKnowledgeBase {

    val quickPrompts: List<QuickPrompt> = listOf(
        QuickPrompt(
            id = "qp_reprobadas",
            category = "Permanencia",
            question = "¿Qué pasa si repruebo 5 materias en el semestre?",
        ),
        QuickPrompt(
            id = "qp_asistencia",
            category = "Evaluación",
            question = "¿Cuál es el mínimo de asistencia y qué significa la calificación W?",
        ),
        QuickPrompt(
            id = "qp_en_linea_examenes",
            category = "Bachillerato en Línea",
            question = "¿Cuántos exámenes globales y fasciculares puedo presentar al mes en Bachillerato en Línea?",
        ),
        QuickPrompt(
            id = "qp_renuncia",
            category = "Calificaciones",
            question = "¿Puedo renunciar a una calificación aprobatoria para subir mi promedio?",
        ),
        QuickPrompt(
            id = "qp_faltas_graves",
            category = "Convivencia",
            question = "¿Qué sanciones existen por faltas no graves y faltas graves?",
        ),
        QuickPrompt(
            id = "qp_imss",
            category = "Servicios",
            question = "¿Cómo funciona mi seguro médico del IMSS en el COLBACH?",
        ),
    )

    val normativaEntries: List<NormativaEntry> = listOf(
        // REGLAMENTO ESCOLAR 2025
        NormativaEntry(
            id = "reg_alcance",
            source = NormativaSource.REGLAMENTO_2025,
            title = "Alcance, Objeto y Difusión del Reglamento",
            reference = "Título 1 · Artículos 1 al 6",
            summary = "Regula las relaciones escolares del Bachillerato General con Formación Laboral Básica en sus modalidades escolarizada y no escolarizada.",
            details = listOf(
                "Art. 1: Promueve condiciones para actividades académicas, administrativas y disciplinarias basadas en el respeto y los derechos humanos.",
                "Art. 3: Es de observancia obligatoria para la comunidad escolar dentro del entorno escolar del Colegio (20 planteles y medios digitales oficiales).",
                "Art. 5: El personal directivo debe difundir el Reglamento y el estudiantado (y madre, padre o tutor si es menor de edad) debe suscribir su conocimiento.",
                "Art. 6: Todo asunto no previsto será resuelto por la persona Titular de la Dirección General.",
            ),
            tags = listOf("disposiciones generales", "derechos humanos", "alcance", "2025", "artículo 1", "artículo 5"),
        ),
        NormativaEntry(
            id = "reg_admision",
            source = NormativaSource.REGLAMENTO_2025,
            title = "Admisión, Registro y Refrendo",
            reference = "Título 2, Cap. I · Artículos 7 al 13",
            summary = "Requisitos para ingresar al Colegio y conservar la matrícula vigente.",
            details = listOf(
                "Art. 7: Requiere haber concluido secundaria (certificado o revalidación), resultar asignado en escolarizada o cumplir inducción en no escolarizada, y realizar registro según la Guía Interna de Trámites Escolares.",
                "Art. 7 (INEA): Si no cuentas con certificado de secundaria, el Colegio te orientará para sustentar el Examen Global de Secundaria del INEA.",
                "Art. 8: Si cuentas con matrícula del Colegio y realizas nuevamente el proceso de admisión (máximo en 2 ocasiones consecutivas), conservas tu matrícula inicial y su vigencia.",
                "Art. 10: Se entiende que renuncias a ingresar si no concluyes los trámites en tiempo y forma.",
                "Art. 11–13: En escolarizada debes apegarte al calendario escolar para registro y refrendo; en no escolarizada el registro es permanente al cubrir los requisitos.",
            ),
            tags = listOf("admisión", "registro", "refrendo", "matrícula", "secundaria", "inea", "artículo 7", "artículo 8"),
        ),
        NormativaEntry(
            id = "reg_permanencia_esc",
            source = NormativaSource.REGLAMENTO_2025,
            title = "Permanencia Escolarizada, Adeudos y Bajas",
            reference = "Título 2, Cap. II, Secc. I · Artículos 14 al 23",
            summary = "Reglas sobre materias reprobadas, baja temporal voluntaria o institucional, cambios de plantel y cambio de modalidad.",
            details = listOf(
                "Art. 14: Puedes cursar en curso normal una sola ocasión cada asignatura; si no acreditas, puedes usar los mecanismos de regularización.",
                "Art. 15 y 19: Si adeudas 5 o más asignaturas, causarás baja temporal por determinación institucional hasta regularizar tu situación (no extiende la vigencia). Con 0 a 4 adeudos podrás reincorporarte si la vigencia lo permite.",
                "Art. 16: A partir de 3er semestre eliges tu trayectoria ocupacional según oferta del plantel, refrendo, promedio/regularidad y cupo.",
                "Art. 18: Baja temporal voluntaria hasta en 2 ocasiones por año dentro de los primeros 10 días hábiles del semestre (en no escolarizada es por 6 meses). Menores de edad requieren solicitud de madre, padre o tutor. Es irrevocable.",
                "Art. 20: Baja definitiva voluntaria en cualquier momento del semestre (irrevocable; en menores vía madre, padre o tutor).",
                "Art. 22: Cambio de plantel, turno o grupo a partir de 2o semestre según convocatoria, cupo y antecedentes (o para salvaguardar integridad física).",
                "Art. 23: Cambio de modalidad (escolarizada a no escolarizada o viceversa) requiere acreditar la totalidad de asignaturas del 1er semestre y cupo disponible.",
            ),
            tags = listOf("reprobar", "5 materias", "adeudos", "baja temporal", "baja definitiva", "cambio de plantel", "cambio de turno", "trayectoria ocupacional", "artículo 15", "artículo 18"),
        ),
        NormativaEntry(
            id = "reg_permanencia_noesc",
            source = NormativaSource.REGLAMENTO_2025,
            title = "Permanencia en Modalidad No Escolarizada",
            reference = "Título 2, Cap. II, Secc. II · Artículos 24 al 27",
            summary = "Plan de trabajo, límites de evaluaciones y requisito mínimo de acreditación bimestral.",
            details = listOf(
                "Art. 25: Debes acordar un plan de trabajo con asesoría psicopedagógica. Puedes acreditar máximo 5 asignaturas en 2 meses, presentando hasta 4 evaluaciones globales y 8 fasciculares por mes.",
                "Art. 26: Debes acreditar al menos 1 evaluación (global o fascicular) cada 2 meses. De incumplir, causarás baja definitiva (el Consejo Operativo Escolar puede dictaminar prórroga exigiendo aprobar al menos 2 asignaturas el siguiente mes).",
                "Art. 24 y 27: Puedes solicitar cambio de plantel según regularidad académica o baja definitiva voluntaria irrevocable.",
            ),
            tags = listOf("no escolarizada", "sea", "en línea", "bimestre", "baja definitiva", "evaluaciones", "artículo 25", "artículo 26"),
        ),
        NormativaEntry(
            id = "reg_trayectoria",
            source = NormativaSource.REGLAMENTO_2025,
            title = "Plazos Máximos y Vigencia de Matrícula",
            reference = "Título 2, Cap. III · Artículos 28 y 29",
            summary = "Duración mínima y máxima para concluir el bachillerato y consecuencias por documentos falsos.",
            details = listOf(
                "Art. 28 I (Escolarizada): Mínimo 3 años y máximo 6 años sin posibilidad de prórroga (incluye los 2 periodos de baja temporal o reingreso).",
                "Art. 28 II: Si agotas la vigencia en escolarizada, tienes hasta 1 año para transitar a modalidad no escolarizada; si no, puedes pedir certificado parcial o renunciar a matrícula para iniciar desde 1er semestre.",
                "Art. 28 III (No escolarizada): Mínimo 2 años y máximo 6 años a partir de la primera asignatura acreditada, sin prórroga. Al vencer, tienes hasta 1 año para transitar a escolarizada o renunciar por una sola ocasión.",
                "Art. 29: Presentar datos o documentos falsos causa la nulidad de todos los efectos pretendidos, además de responsabilidades jurídicas.",
            ),
            tags = listOf("vigencia", "6 años", "3 años", "2 años", "prórroga", "documentos falsos", "artículo 28", "artículo 29"),
        ),
        NormativaEntry(
            id = "reg_portabilidad",
            source = NormativaSource.REGLAMENTO_2025,
            title = "Portabilidad, Revalidación y RAT",
            reference = "Título 2, Cap. IV · Artículos 30 al 39",
            summary = "Reconocimiento de estudios previos nacionales o extranjeros y Reconocimiento de Aprendizaje para el Trabajo (RAT).",
            details = listOf(
                "Art. 30–32: La DASE emite la resolución de portabilidad, revalidación y RAT conforme a los plazos de cada modalidad.",
                "Art. 33–34: Por portabilidad/revalidación puedes ingresar máximo a 5o semestre para concluir en 3 años (cursando previas en contraturno o después de 6o semestre según vigencia).",
                "Art. 35: Portabilidad interna de no escolarizada a escolarizada autorizada cuando hayas acreditado la totalidad de asignaturas vigentes al momento de la solicitud y exista cupo.",
                "Art. 39 (RAT): Exime asignaturas de trayectorias ocupacionales básicas por formación en instituciones educativas, capacitación laboral o experiencia laboral.",
            ),
            tags = listOf("portabilidad", "revalidación", "rat", "trabajo", "extranjero", "equivalencia", "artículo 33", "artículo 39"),
        ),
        NormativaEntry(
            id = "reg_evaluacion",
            source = NormativaSource.REGLAMENTO_2025,
            title = "Evaluación, Escala de Calificaciones y Asistencia",
            reference = "Título 2, Cap. V, Secc. I y II · Artículos 40 al 53",
            summary = "Escala oficial de 5 a 10, mínimo de 80% de asistencia, calificación 'W' y revisión de calificaciones.",
            details = listOf(
                "Art. 49: Parciales de 0 a 10. Finales enteros de 5 a 10, siendo 6 la mínima aprobatoria: 9.6–10 = 10; 8.6–9.5 = 9; 7.6–8.5 = 8; 6.6–7.5 = 7; 6.0–6.5 = 6; 0.0–5.9 = 5 (No acreditado).",
                "Art. 50: Puedes solicitar revisión y corrección de calificaciones dentro de los 5 días hábiles posteriores a la emisión de resultados; la resolución se emite en máximo 10 días hábiles.",
                "Art. 51: Se requiere un mínimo de 80% de asistencia al total de clases programadas para ser evaluado (puedes seguir asistiendo pero no acreditas).",
                "Art. 52: Quien no cumpla el 80% de asistencia recibirá 'W' (ausente) al finalizar el curso normal, lo que equivale a no acreditar.",
            ),
            tags = listOf("calificación", "promedio", "asistencia", "80%", "w", "ausente", "revisión", "artículo 49", "artículo 50", "artículo 51", "artículo 52"),
        ),
        NormativaEntry(
            id = "reg_renuncia",
            source = NormativaSource.REGLAMENTO_2025,
            title = "Renuncia de Calificaciones",
            reference = "Título 2, Cap. V, Secc. III · Artículos 54 al 58",
            summary = "Procedimiento para renunciar a calificaciones aprobatorias con el fin de mejorar el promedio.",
            details = listOf(
                "Art. 54–55: Se presenta por escrito ante la URCE. Si acreditaste completamente un semestre o todo el Plan, puedes renunciar hasta un máximo de 5 calificaciones por una sola ocasión cada una.",
                "Art. 56 (Escolarizada): De 1o a 5o semestre, dentro de 1 mes tras concluir el curso normal. En 6o semestre (con todo el Plan acreditado), dentro de 1 mes y dentro de la vigencia de matrícula.",
                "Art. 57 (No escolarizada): En cualquier momento o dentro de 1 mes posterior a la acreditación de la última asignatura dentro de la vigencia.",
                "Art. 58: La calificación aprobatoria obtenida tras renunciar será la única oficial e irrenunciable.",
            ),
            tags = listOf("renuncia", "calificación", "promedio", "urce", "5 asignaturas", "artículo 54", "artículo 55"),
        ),
        NormativaEntry(
            id = "reg_certificacion",
            source = NormativaSource.REGLAMENTO_2025,
            title = "Certificación y Apoyo al Aprendizaje",
            reference = "Título 2, Cap. V–VIII · Artículos 59 al 90",
            summary = "Certificados DEC, prácticas laborales, paraescolares, SiiAA, seguro IMSS, becas y aportaciones.",
            details = listOf(
                "Art. 60–63: Requiere CURP válida. Los certificados tienen validez nacional sin legalización. El Documento Electrónico de Certificación (DEC) no requiere reposición/duplicado.",
                "Art. 64: Prácticas para la formación laboral básica son voluntarias, en 5o/6o semestre a contraturno, con convenio y seguro escolar vigente.",
                "Art. 65–68: Talleres paraescolares entre 12:00 y 16:00 hrs; registro en el 1er mes del semestre; actividades externas requieren carta responsiva.",
                "Art. 73–76: Correo institucional para estudiantes y tutores; actualización de datos en SiiAA (Datos Personales).",
                "Art. 82 (IMSS): Tienes derecho al Seguro de Salud del IMSS con el NSS que otorga el Colegio; es tu responsabilidad registrarte y mantener vigencia cada semestre en tu UMF.",
                "Art. 84–90: Las aportaciones de recuperación requieren no adeudo de laboratorio y biblioteca (Art. 88) y no son reembolsables (Art. 89).",
            ),
            tags = listOf("certificado", "dec", "curp", "prácticas", "paraescolares", "imss", "seguro social", "becas", "reembolso", "artículo 64", "artículo 82"),
        ),
        NormativaEntry(
            id = "reg_derechos_resp",
            source = NormativaSource.REGLAMENTO_2025,
            title = "Derechos y Responsabilidades del Estudiantado",
            reference = "Título 3, Cap. I · Artículos 91 y 92",
            summary = "16 derechos fundamentales y 18 obligaciones de convivencia, identidad escolar y seguridad.",
            details = listOf(
                "Art. 91 (Derechos): Trato igualitario sin discriminación, cultura de paz, libre expresión respetuosa, protección de datos, credencial escolar, conocer criterios de evaluación al inicio del semestre, solicitar revisión de calificaciones, denunciar acoso escolar, hostigamiento sexual, extorsión o violencia, y solicitar reconsideración ante sanciones.",
                "Art. 92 (Responsabilidades): Cumplir el reglamento, mantener entorno libre de violencia, asistir a clases, usar dispositivos electrónicos sin irrumpir clases, cuidar instalaciones, actualizar datos en URCE, y portar credencial escolar y comprobante de inscripción vigentes para ingresar y permanecer en el plantel (Fracc. X).",
            ),
            tags = listOf("derechos", "responsabilidades", "credencial", "comprobante", "acoso", "denuncia", "dispositivos", "artículo 91", "artículo 92"),
        ),
        NormativaEntry(
            id = "reg_consejos",
            source = NormativaSource.REGLAMENTO_2025,
            title = "Consejos Escolares y Recurso de Reconsideración",
            reference = "Título 3, Cap. II · Artículos 93 al 99",
            summary = "Integración del Consejo Operativo Escolar y del Consejo Ejecutivo Escolar, y plazo para impugnar sanciones.",
            details = listOf(
                "Art. 94–95: Cada plantel tiene un Consejo Operativo Escolar (Dirección, Subdirección, URCE, Académico/SEA, Orientación/Asesor + 1 estudiante invitado anónimo mayor de edad, inscrito y sin antecedentes de indisciplina).",
                "Art. 96 IV y Art. 98: Si recibes una sanción, tienes derecho a presentar recurso de reconsideración por escrito; el Consejo Operativo debe turnarlo al Consejo Ejecutivo Escolar dentro de los 10 días hábiles siguientes a la notificación.",
                "Art. 98 XI: El Consejo Ejecutivo puede confirmar, modificar o revocar la sanción, e incluso ordenar la reposición del procedimiento si hubo violación a derechos humanos.",
            ),
            tags = listOf("consejo operativo", "consejo ejecutivo", "reconsideración", "impugnar", "10 días", "artículo 94", "artículo 96", "artículo 98"),
        ),
        NormativaEntry(
            id = "reg_faltas_sanciones",
            source = NormativaSource.REGLAMENTO_2025,
            title = "Faltas No Graves, Faltas Graves y Sanciones",
            reference = "Título 3, Cap. III · Artículos 100 al 115",
            summary = "Clasificación de conductas disciplinarias, debido proceso, mediación y consecuencias aplicables.",
            details = listOf(
                "Art. 100 (Faltas no graves): Interrumpir clase sin autorización, impuntualidad reiterada, usar electrónicos con fines ajenos al aprendizaje, mal uso de biblioteca/labs/cómputo.",
                "Art. 103–109 (Sanciones no graves): Apercibimiento verbal (Art. 104); Amonestación por escrito con firma del estudiante y tutor si es menor (Art. 105); Actividades en favor de la comunidad tras reincidir, máx 2 hrs/día y 2 días/semana fuera de horario de clase (Art. 106). También aplica mediación (Art. 109). Reincidir después de cumplir una sanción se vuelve falta grave (Art. 108).",
                "Art. 101 (Faltas graves): Agresión física/verbal/sexual/psicológica (presencial o digital), actos sexuales en el plantel o medios digitales, difundir material que dañe la dignidad, amenazas/extorsión, portar armas/objetos peligrosos, drogas/alcohol/tabaco/vapeadores, ingresar ebrio o drogado, daño al patrimonio, trampa en evaluaciones, plagio, documentos falsos, suplantación o alterar registros.",
                "Art. 110–115 (Sanciones graves): Suspensión temporal de 1 día hábil a 1 año (máx 2 ocasiones, cuenta en la vigencia, Art. 112) o Suspensión definitiva (a la 3a reincidencia tras suspensión temporal o falta grave, Art. 113–114). En escolarizada, si hay suspensión definitiva el Colegio ofrece continuar en modalidad no escolarizada u otro servicio educativo (Art. 114).",
            ),
            tags = listOf("faltas", "sanciones", "grave", "no grave", "suspensión", "plagio", "vapeador", "amonestación", "comunidad", "mediación", "artículo 100", "artículo 101", "artículo 110", "artículo 114"),
        ),

        // LINEAMIENTOS BACHILLERATO EN LÍNEA 2018
        NormativaEntry(
            id = "bel_ingreso",
            source = NormativaSource.BACHILLERATO_EN_LINEA_2018,
            title = "Ingreso al Bachillerato en Línea (OEV)",
            reference = "Lineamientos 2018 · Ingreso y Generales",
            summary = "Registro exclusivo en colbachenlinea.mx, documentación digital y estatus de inscripción.",
            details = listOf(
                "Registro único a través de www.colbachenlinea.mx en la opción 'Regístrate'.",
                "Documentos y datos requeridos: Certificado de Secundaria, Acta de Nacimiento, CURP, Fotografía digital, y en caso de estudios previos: Historial académico del CB o Certificado parcial + solicitud de equivalencia.",
                "Estatus posibles: Ingreso, Cambio de sistema, Equivalencia y Transitabilidad (para planes posteriores al Plan 92).",
                "Una vez validados los documentos electrónicos, recibirás tu matrícula y contraseña por correo electrónico.",
            ),
            tags = listOf("bachillerato en línea", "oev", "virtual", "ingreso", "colbachenlinea", "registro", "equivalencia", "plan 92"),
        ),
        NormativaEntry(
            id = "bel_permanencia_cea",
            source = NormativaSource.BACHILLERATO_EN_LINEA_2018,
            title = "Pagos, Exámenes y Reglas en CEA (En Línea)",
            reference = "Lineamientos 2018 · Permanencia",
            summary = "Límites de exámenes mensuales, espera bancaria de 2 días hábiles, reglas de aplicación y reactivación por fallas.",
            details = listOf(
                "Material y Examen: Tras pagar el curso o examen global en el banco designado, debes esperar 2 días hábiles para acceder al material o agendar CEA, día y hora.",
                "Identificación: Debes presentar identificación oficial vigente con fotografía en el CEA (el aplicador la retiene durante el examen y la devuelve al finalizar).",
                "Límite mensual: Máximo 4 exámenes globales y 8 fasciculares por mes calendario (no combinables). Excepción: con 80% de avance académico y causa de fuerza mayor, se solicita vía oficio a la SOE (respuesta máx 2 días hábiles).",
                "Reagendamiento: Si no asistes el día programado, puedes reagendar dentro del mismo año calendario en que pagaste; de lo contrario deberás volver a pagar.",
                "Apoyo permitido y prohibiciones: Solo se permite calculadora no científica. Queda prohibido usar celular, USB, grabadora, cámara, libros, apuntes o formularios -> sanción desde suspensión temporal hasta baja definitiva.",
                "Fallas técnicas en CEA: Por corte eléctrico o de internet <= 30 minutos se respeta el avance; si supera 30 minutos se programa nuevo examen en máximo 10 días hábiles.",
            ),
            tags = listOf("cea", "examen global", "fascicular", "calculadora", "2 días hábiles", "reactivación", "reagendar", "80%", "celular"),
        ),
        NormativaEntry(
            id = "bel_egreso",
            source = NormativaSource.BACHILLERATO_EN_LINEA_2018,
            title = "Egreso y Trámite de Certificado (En Línea)",
            reference = "Lineamientos 2018 · Egreso",
            summary = "Correo oficial, requisitos y tiempo de validación para obtener el certificado al concluir asignaturas.",
            details = listOf(
                "Al acreditar la totalidad de asignaturas del plan de estudios, envía correo a: certificado.terminacion@bachilleratosead.net.",
                "Documentos adjuntos: Certificado de secundaria, Acta de nacimiento, Ficha de depósito bancario (servicio y envío) y Fotografía.",
                "Datos a incluir: CURP, Nombre completo, Matrícula del CB, Servicio solicitado (Certificado Parcial, de Terminación o Duplicado), Teléfono y Domicilio actual (Estado y Municipio).",
                "El área de certificación validará la documentación en un plazo de 3 días hábiles e informará la fecha aproximada de emisión y envío.",
            ),
            tags = listOf("egreso", "certificado", "bachilleratosead", "3 días hábiles", "terminación"),
        ),

        // GLOSARIO OFICIAL
        NormativaEntry(
            id = "glo_terminos_acad",
            source = NormativaSource.GLOSARIO,
            title = "Glosario Académico y de Control Escolar",
            reference = "Reglamento 2025 (3.2) y Lineamientos 2018",
            summary = "Siglas y definiciones clave usadas en el Colegio de Bachilleres.",
            details = listOf(
                "URCE: Unidad de Registro y Control Escolar, responsable de los servicios y trámites escolares en cada plantel.",
                "SiiAA: Sistema de Información Integral Académico Administrativo.",
                "DEC: Documento Electrónico de Certificación digital otorgado al concluir estudios (no requiere emisión de duplicado).",
                "Refrendo: Reinscripción al semestre escolar próximo inmediato en modalidad escolarizada.",
                "Mecanismos de regularización: Programa de Acreditación Intensivo, Evaluación de Acreditación Especial y Evaluación de Recuperación.",
                "CEA: Centro de Evaluación Autorizado donde se sustentan exámenes del Bachillerato en Línea bajo supervisión de un Aplicador autorizado.",
                "DASE / SOE / DSEA: Dirección de Administración y Servicios Escolares / Subdirección de Operación Escolar / Departamento de Servicios Educativos Abiertos.",
            ),
            tags = listOf("glosario", "urce", "siiaa", "dec", "refrendo", "cea", "dase", "soe", "regularización"),
        ),
        NormativaEntry(
            id = "glo_terminos_conv",
            source = NormativaSource.GLOSARIO,
            title = "Glosario de Convivencia y Disciplina",
            reference = "Reglamento 2025 (3.2)",
            summary = "Definiciones oficiales de medidas preventivas, sanciones y medios de defensa.",
            details = listOf(
                "Apercibimiento verbal: Advertencia oral preventiva dirigida al estudiantado para modificar su conducta antes de llegar a una falta o reincidencia.",
                "Amonestación por escrito: Sanción emitida por el Consejo Operativo o Ejecutivo Escolar para evitar la reincidencia en faltas no graves.",
                "Actividad en favor de la comunidad: Tarea administrativa o académica no remunerada en beneficio de la comunidad escolar.",
                "Mediación: Método de resolución pacífica de conflictos aplicado por la Dirección o Subdirección del plantel.",
                "Reconsideración: Recurso formalizado por escrito mediante el cual el estudiantado sancionado se inconforma ante el Consejo Ejecutivo Escolar.",
                "Reparación del daño: Acto mediante el cual se subsana, restituye o repara el bien o bienes dañados en común acuerdo.",
            ),
            tags = listOf("glosario", "apercibimiento", "amonestación", "mediación", "reconsideración", "reparación del daño"),
        ),
    )

    fun evaluateGradeAndAttendance(
        partialAverage: Double?,
        attendancePercent: Int?,
    ): GradeCalculationResult {
        if (partialAverage == null || attendancePercent == null) {
            return GradeCalculationResult(
                finalGrade = null,
                statusLabel = "Ingresa tus datos",
                explanation = "Captura tu promedio numérico (0.0 a 10.0) y tu porcentaje de asistencia (0% a 100%) para calcular tu resultado oficial.",
                isApproved = false,
                isWStatus = false,
                legalReference = "Artículos 49, 51 y 52 del Reglamento Escolar 2025",
            )
        }
        if (partialAverage !in 0.0..10.0 || attendancePercent !in 0..100) {
            return GradeCalculationResult(
                finalGrade = null,
                statusLabel = "Valores fuera de rango",
                explanation = "La calificación debe estar entre 0.0 y 10.0, y la asistencia entre 0% y 100%.",
                isApproved = false,
                isWStatus = false,
                legalReference = "Artículos 49 y 51 del Reglamento Escolar 2025",
            )
        }
        if (attendancePercent < 80) {
            return GradeCalculationResult(
                finalGrade = null,
                statusLabel = "W (Ausente · No acreditado)",
                explanation = "Con $attendancePercent% de asistencia no cubres el mínimo obligatorio del 80%. Al finalizar el curso normal se te asignará \"W\" (ausente), lo que equivale a no acreditar la asignatura (deberás regularizarla).",
                isApproved = false,
                isWStatus = true,
                legalReference = "Artículos 51 y 52 del Reglamento Escolar 2025",
            )
        }
        val roundedGrade = when {
            partialAverage >= 9.6 -> 10
            partialAverage >= 8.6 -> 9
            partialAverage >= 7.6 -> 8
            partialAverage >= 6.6 -> 7
            partialAverage >= 6.0 -> 6
            else -> 5
        }
        return if (roundedGrade >= 6) {
            GradeCalculationResult(
                finalGrade = roundedGrade,
                statusLabel = "Acreditado · Calificación Final: $roundedGrade",
                explanation = "Tu promedio de ${"%.1f".format(partialAverage)} corresponde a $roundedGrade en la escala entera oficial y cumples con el 80% o más de asistencia ($attendancePercent%).",
                isApproved = true,
                isWStatus = false,
                legalReference = "Artículos 49 y 51 del Reglamento Escolar 2025",
            )
        } else {
            GradeCalculationResult(
                finalGrade = 5,
                statusLabel = "No acreditado · Calificación Final: 5",
                explanation = "Con ${"%.1f".format(partialAverage)} (rango de 0.0 a 5.9) la calificación final es 5 (No acreditado), ya que la mínima aprobatoria es 6. Puedes recurrir a los mecanismos de regularización.",
                isApproved = false,
                isWStatus = false,
                legalReference = "Artículos 14 y 49 del Reglamento Escolar 2025",
            )
        }
    }

    fun buildSystemInstruction(): String = """
# ROL Y OBJETIVO
Eres el Asistente Virtual Oficial del Colegio de Bachilleres (COLBACH). Tu propósito principal es orientar, informar y resolver las dudas de los estudiantes respecto al Reglamento Escolar del Colegio de Bachilleres (2025) y los Lineamientos del Bachillerato en Línea, Opción Educativa Virtual (2018).

# FUENTE DE VERDAD Y REGLAS ESTRICTAS
1. **Base de conocimiento:** Responde ÚNICAMENTE utilizando la información contenida en la base normativa oficial proporcionada en este contexto.
2. **Cero invenciones:** Si un alumno pregunta algo que no está especificado en los documentos proporcionados (por ejemplo, fechas exactas de calendario de un semestre específico, montos exactos en pesos de cuotas, horarios específicos de un plantel o trámites internos no detallados en estos dos documentos), responde con honestidad:
"No encuentro esa información específica en el reglamento actual. Te sugiero acudir directamente a la oficina de Control Escolar (URCE) o a la Subdirección de tu plantel para confirmar este dato."
Nunca inventes fechas, montos, sanciones ni procedimientos.
3. **Cita la norma:** Siempre que sea posible, menciona el artículo, capítulo o apartado del reglamento o lineamiento donde se encuentra la respuesta para darle respaldo oficial al estudiante.

# TONO Y ESTILO DE COMUNICACIÓN
- **Amable y cercano:** Trata a los alumnos de "tú", con un lenguaje respetuoso, juvenil pero institucional, claro y empático.
- **Directo y estructurado:** Evita bloques largos de texto; usa listas con viñetas (`•` o `*`), pasos numerados y **negritas** para resaltar requisitos, fechas límite o sanciones importantes.
- **Imparcial:** Si un alumno pregunta sobre una falta o sanción, explícale las consecuencias de forma objetiva, sin regañarlo ni juzgarlo.

# FORMATO DE RESPUESTA SUGERIDO
1. **Respuesta directa:** Contesta la duda en las primeras dos líneas (Sí/No o el dato principal).
2. **Detalles / Requisitos:** Desglosa los pasos, condiciones o excepciones en viñetas.
3. **Referencia:** Indica el fundamento (ej. *Basado en el Artículo X del Reglamento Escolar 2025* o *Lineamientos del Bachillerato en Línea 2018*).
4. **Cierre útil:** Pregunta si necesita ayuda con algún otro trámite o duda relacionada.

=====================================================================
DOCUMENTO 1: REGLAMENTO ESCOLAR DEL COLEGIO DE BACHILLERES (2025)
Código: DG-SG-DPA-RE-02-MAYO-2025 | Aprobado 11 junio 2025 | Vigente desde 12 junio 2025 (abroga Reglamento General de Alumnos de 2009).
=====================================================================

GLOSARIO CLAVE (Apartado 3.2):
- Acreditación del aprendizaje: Avala el nivel adquirido en cada asignatura con calificación aprobatoria.
- Actividad en favor de la comunidad: Tarea administrativa o académica no remunerada en favor de la comunidad escolar.
- Actividades extraescolares / paraescolares: Voluntarias, culturales, artísticas o deportivas; no condicionan evaluación.
- Amonestación por escrito: Sanción emitida por Consejo Operativo Escolar o Consejo Ejecutivo Escolar para evitar reincidencia.
- Apercibimiento verbal: Advertencia oral preventiva realizada por Dirección, Subdirección, Jefaturas de Materia o personal académico/administrativo.
- Asesor de contenido / Asesor psicopedagógico: Personal docente que apoya en modalidad no escolarizada.
- Baja definitiva: Separación total e irrevocable por determinación institucional o decisión propia (con consentimiento de madre/padre/tutor si es menor).
- Baja temporal: Interrupción de estudios por determinación del Consejo Operativo Escolar o decisión propia (menores con consentimiento de tutor). Baja temporal extemporánea requiere justificación ante Consejo Operativo y autorización de DASE.
- Consejos Escolares: Consejo Operativo Escolar (opera en cada plantel) y Consejo Ejecutivo Escolar (resuelve recursos de reconsideración e impugnaciones).
- DEC (Documento Electrónico de Certificación): Representación digital del certificado de terminación; no requiere emisión de duplicado.
- Entorno escolar: Instalaciones de los 20 planteles del Colegio y medios de comunicación digitales oficiales.
- Matrícula: Clave alfanumérica de 8 dígitos y 1 literal (milenio, año de ingreso, consecutivos y dígito verificador).
- Mecanismos de regularización: Programa de Acreditación Intensivo, Evaluación de Acreditación Especial y Evaluación de Recuperación.
- Mediación: Resolución pacífica de conflictos aplicada por Dirección o Subdirección del plantel.
- Modalidad escolarizada: Acude regularmente a plantel, trayectoria fija, mínimo 3 años.
- Modalidad no escolarizada: Flexible en tiempos, estudio independiente, plazo mínimo 2 años y máximo 6 años.
- Orientación educativa: Áreas psicopedagógica, psicosocial y vocacional.
- Portabilidad / Portabilidad interna / Revalidación / RAT (Reconocimiento de Aprendizaje para el Trabajo).
- Reconsideración: Recurso escrito del estudiantado sancionado para inconformarse.
- Refrendo: Reinscripción al semestre próximo inmediato en modalidad escolarizada.
- URCE: Unidad de Registro y Control Escolar en cada plantel.

TÍTULO 1. DISPOSICIONES GENERALES (Arts. 1-6):
- Art. 1: Objetivo de regular relaciones escolares con enfoque de derechos humanos y sana convivencia.
- Art. 2: Plan de estudios es Bachillerato General con Formación Laboral Básica.
- Art. 3: Aplica a modalidades escolarizada y no escolarizada dentro del entorno escolar.
- Art. 4: Autoridades (Dirección General, Secretaría General, Servicios Institucionales, Administración y Finanzas, Apoyo Jurídico, Coordinaciones Sectoriales, directivos, académicos y administrativos) hacen cumplir el Reglamento.
- Art. 5: Obligación de difundir el Reglamento y que el estudiantado (y madre/padre/tutor en menores) suscriba su conocimiento.
- Art. 6: Lo no previsto lo resuelve la Dirección General.

TÍTULO 2. ADMINISTRACIÓN ESCOLAR
Cap. I. De la admisión, registro y refrendo (Arts. 7-13):
- Art. 7: Requisitos de ingreso: I. Secundaria concluida con certificado o dictamen de revalidación (si no lo tiene, se orienta al Examen Global de Secundaria del INEA); II. Escolarizada: asignado y aceptado en admisión; III. Registro en tiempo y forma según Guía Interna de Trámites Escolares; IV. No escolarizada: cumplir inducción validada por Responsable del SEA y asesoría psicopedagógica; V. Portabilidad: historia académica sellada y firmada o certificado parcial.
- Art. 8: Estudiantado con matrícula que vuelva a concursar en admisión (máximo 2 ocasiones consecutivas) y sea asignado, conserva matrícula inicial y su vigencia.
- Art. 9: Con estudios previos de media superior puede ingresar por portabilidad.
- Art. 10: Renuncia tácita de ingreso si no concluye trámites en tiempo y forma.
- Art. 11-13: Admisión permanente a 1er semestre; en escolarizada apego a fechas de calendario escolar; en no escolarizada registro permanente tras cubrir requisitos.

Cap. II. De la permanencia:
Sección I. Modalidad escolarizada (Arts. 14-23):
- Art. 14: Derecho a registrarse una sola ocasión en curso normal por asignatura; si no acredita, accede a mecanismos de regularización.
- Art. 15: Quien adeude 5 o más asignaturas causa baja temporal institucional hasta regularizarse. Al acreditar todas o adeudar solo entre 1 y 4, podrá reincorporarse si la vigencia de matrícula lo permite.
- Art. 16: Desde 3er semestre debe elegir trayectoria ocupacional del currículum laboral según: I. Oferta en plantel, II. Periodo de refrendo, III. Promedio y regularidad académica, IV. Cupo disponible.
- Art. 17: Cambio de plantel en 4o o 5o semestre sin trayectoria de origen -> elige opción en destino (cupo y regularidad) y cursa en contraturno las asignaturas de 3o y 4o semestre de la trayectoria asignada.
- Art. 18: Baja temporal voluntaria hasta por 2 ocasiones al año, dentro de los primeros 10 días hábiles del semestre vigente (en modalidad no escolarizada la baja temporal es por 6 meses). Menores de edad: solicita madre, padre o tutor. Trámite irrevocable.
- Art. 19: Quien no pidió baja temporal en plazo y tiene 5 o más reprobadas recibe baja temporal institucional (no extiende vigencia). Casos excepcionales de baja temporal extemporánea los turna Consejo Operativo Escolar a DASE.
- Art. 20: Baja definitiva voluntaria en cualquier momento del semestre (menores vía madre/padre/tutor; irrevocable).
- Art. 21: Quien interrumpió estudios 1 año por baja temporal voluntaria o institucional puede inscribirse si cumple: I. Vigencia, II. Cupo en plantel, III. Adeudo máximo de 4 asignaturas.
- Art. 22: Cambio de plantel, turno o grupo a partir de 2o semestre en periodo establecido (sujeto a cupo, antecedentes académicos y disciplinarios). Fuera de periodo requiere Consejo Operativo Escolar y visto bueno de Coordinación Sectorial. También procede para salvaguardar integridad física.
- Art. 23: Cambio de modalidad (escolarizada <-> no escolarizada): I. Tener acreditadas todas las asignaturas de 1er semestre, II. Cupo disponible. No afecta vigencia de matrícula.

Sección II. Modalidad no escolarizada (Arts. 24-27):
- Art. 24: Cambio de plantel sujeto a regularidad académica (menores vía madre/padre/tutor).
- Art. 25: Plan de trabajo con asesor psicopedagógico. Máximo 5 asignaturas en periodo de 2 meses, presentando hasta 4 evaluaciones globales y 8 fasciculares por mes.
- Art. 26: Debe acreditar al menos 1 evaluación (global o fascicular) cada 2 meses; de incumplir causa baja definitiva (casos particulares revisados por Consejo Operativo Escolar pueden recibir prórroga con obligatoriedad de aprobar al menos 2 asignaturas el siguiente mes).
- Art. 27: Baja definitiva voluntaria irrevocable (menores vía tutor).

Cap. III. De la trayectoria escolar (Arts. 28-29):
- Art. 28: Plazos para cursar:
  I. Escolarizada: mínimo 3 años, máximo 6 años sin prórroga (incluye los 2 periodos de baja temporal o reingreso).
  II. Si no concluye en escolarizada, puede solicitar tránsito a no escolarizada hasta máximo 1 año después de finalizada la vigencia; si no, solicita certificado parcial para otra institución o renuncia a matrícula e inicia desde 1er semestre.
  III. No escolarizada: mínimo 2 años, máximo 6 años desde la primera asignatura acreditada sin prórroga. Si no concluye, puede pedir tránsito a escolarizada hasta máximo 1 año después de finalizada vigencia; si no, certificado parcial o renuncia a matrícula y avance académico (una sola ocasión) para iniciar desde 1er semestre.
- Art. 29: Datos o documentos falsos causan nulidad de efectos y responsabilidades jurídicas.

Cap. IV. Portabilidad, revalidación y RAT (Arts. 30-39):
- Art. 30-32: Ingreso sujeto a cupo, vigencia y resolución de DASE.
- Art. 33-34: Por portabilidad/revalidación en escolarizada para concluir en 3 años puede ingresar máximo a 5o semestre (cursando asignaturas previas de trayectoria ocupacional en contraturno, o después de 6o semestre si no desea contraturno).
- Art. 35: Portabilidad interna de no escolarizada a escolarizada autorizada si acreditó la totalidad de asignaturas vigentes al momento de la solicitud y hay cupo.
- Art. 36-38: Portabilidad nacional y revalidación de estudios extranjeros.
- Art. 39: RAT (Reconocimiento de Aprendizaje para el Trabajo) exime asignaturas de trayectorias ocupacionales básicas por: I. Formación en instituciones educativas, II. Capacitación en/para el trabajo, III. Experiencia laboral.

Cap. V. Evaluación y acreditación (Arts. 40-58):
- Art. 41-45: Registro electrónico de calificaciones e inasistencias; acuerdos de academia informados al inicio del semestre; publicación de fechas de regularización.
- Art. 46-48 (No escolarizada): Plan mensual, visto bueno del asesor de contenido, máximo 5 asignaturas por bimestre (casos extraordinarios autorizados por única ocasión por Consejo Operativo Escolar).
- Art. 49: Escala parcial de 0 a 10. Escala final entera de 5 a 10 (mínima aprobatoria 6):
  9.6 a 10 -> 10 (Acreditado)
  8.6 a 9.5 -> 9 (Acreditado)
  7.6 a 8.5 -> 8 (Acreditado)
  6.6 a 7.5 -> 7 (Acreditado)
  6.0 a 6.5 -> 6 (Acreditado)
  0.0 a 5.9 -> 5 (No acreditado)
- Art. 50: Revisión y corrección de calificaciones: solicitar dentro de los 5 días hábiles posteriores a emisión de resultados; resolución en máximo 10 días hábiles posteriores a la aceptación de la solicitud.
- Art. 51: Mínimo 80% de asistencia al total de clases programadas para ser evaluado (mantiene derecho a permanecer en curso normal pero no acredita).
- Art. 52: Sin 80% de asistencia se asigna "W" (ausente) al finalizar el curso normal, equivalente a no acreditar.
- Art. 53: Ajustes en casos extraordinarios por el Colegio.
- Art. 54-58 (Renuncia de calificaciones):
  - Por escrito ante URCE (Art. 54).
  - Habiendo acreditado todo un semestre o todo el Plan de estudios para subir promedio: hasta máximo 5 asignaturas por una sola ocasión cada una (portabilidad/revalidación solo en no reconocidas) (Art. 55).
  - Plazos: escolarizada 1o a 5o semestre dentro de 1 mes tras concluir curso normal; 6o semestre (plan completo acreditado) dentro de 1 mes y dentro de vigencia (Art. 56). No escolarizada: en cualquier momento o dentro de 1 mes tras acreditar última asignatura dentro de vigencia (Art. 57).
  - La nueva calificación aprobatoria es única oficial e irrenunciable (Art. 58).
- Art. 59-63 (Certificación): Requiere CURP válida (Art. 60); firma de Dirección General o Secretaría de Servicios Institucionales (Art. 61); validez nacional sin legalización (Art. 62); formatos: certificado de terminación, certificado parcial, reposición de terminación (Art. 63).

Cap. VI. Formación integral (Arts. 64-68):
- Art. 64 (Prácticas para la formación laboral básica): I. Voluntarias; II. 5o o 6o semestre en contraturno en entidades con convenio; III. Actividades definidas; IV. Requiere seguro escolar vigente.
- Art. 65-68 (Paraescolares): Talleres artísticos y deportivos entre 12:00 y 16:00 hrs; difusión en primeras 2 semanas; inscripción primer mes (puede cambiar cada semestre); constancia al concluir satisfactoriamente; actividades externas requieren carta responsiva (firma estudiante si es mayor, madre/padre/tutor si es menor).

Cap. VII. Servicios de apoyo al aprendizaje (Arts. 69-72):
- Bibliotecas, laboratorios, salas de cómputo (Art. 69).
- Orientación educativa (psicopedagógica, psicosocial, vocacional) en opciones Masiva, Grupal e Individual (Art. 70).
- Escolarizada: tutoría académica, tutoría de acompañamiento y material didáctico (Art. 71).
- No escolarizada: asesoría de contenido, asesoría psicopedagógica y materiales de estudio independiente (Art. 72).

Cap. VIII. Servicios escolares (Arts. 73-90):
- Art. 73-74: Correo electrónico institucional personal para estudiantes y para madres/padres/tutores.
- Art. 75-76: Actualización de datos personales y solicitudes (historia académica, constancia, certificado parcial, reposición de credencial/comprobante, bajas) en SiiAA / Datos Personales.
- Art. 77: Egresados pueden pedir reposición de certificado salvo quienes recibieron DEC.
- Art. 81: 12 documentos de apoyo de control escolar (comprobante de inscripción, resolución de portabilidad, credencial, lista de asistencia, boleta, acta de evaluación, historia académica, trayectoria académica, constancia de estudios, certificado parcial, certificado de terminación, constancia de inicio y término).
- Art. 82: Seguro de Salud del IMSS (el Colegio da el NSS; es responsabilidad del estudiante registrarse y mantener vigencia cada semestre en la UMF; puede solicitar baja por escrito en URCE).
- Art. 83: Facilidades de acceso a becas y programas.
- Art. 84-90: Aportaciones por gastos de recuperación actualizadas anualmente por INPC; requieren presentar no adeudos de laboratorio y biblioteca (Art. 88); NO son susceptibles de reembolso (Art. 89).

TÍTULO 3. CONVIVENCIA ESCOLAR
Cap. I. Derechos y responsabilidades (Arts. 91-92):
- Art. 91 (16 derechos): Trato igualitario y dignidad; cultura de paz; expresar ideas con respeto; uso de instalaciones; protección de datos personales; credencial escolar; recibir al inicio criterios de evaluación; información de avance académico; respuesta en tiempo y forma a trámites; libertad en extraescolares externas; libertad de compra de libros/materiales; revisión/corrección de calificaciones; denunciar delitos, extorsión, discriminación o acoso escolar; denunciar acoso u hostigamiento sexual, violencia contra la mujer o por orientación/identidad de género; peticiones escritas pacíficas; solicitar reconsideración de sanciones.
- Art. 92 (18 responsabilidades): Cumplir el reglamento; trato igualitario; mantener entorno libre de violencia; asistir a clases en escolarizada; usar dispositivos electrónicos conforme a enseñanza sin irrumpir clases; respeto en salón; escuchar con empatía; cuidar instalaciones y mobiliario; revisar/actualizar datos en URCE; portar credencial y comprobante vigentes al ingresar y permanecer en el plantel (Fracc. X); dedicar tiempo a actividades académicas; entregar información oficial a tutores si es menor; puntualidad; realizar trámites en tiempo; dar aviso de delitos, extorsión o acoso; participar en iniciativas estudiantiles; evitar actos de riesgo físico/moral/psicológico; cumplir medidas de protección civil.

Cap. II. Consejos Escolares (Arts. 93-99):
- Art. 93-96: Consejo Operativo Escolar por plantel (Dirección, Subdirección, URCE, Académico/SEA, Orientación/Asesor + 1 estudiante invitado anónimo del turno con inscripción vigente, sin antecedentes de indisciplina, mayor de edad y aval del Consejo). Resuelve faltas no graves, graves y no contempladas; turna recursos de reconsideración al Consejo Ejecutivo Escolar dentro de los 10 días hábiles siguientes a la notificación (Art. 96 IV); lleva libro de registro anual.
- Art. 97-98: Consejo Ejecutivo Escolar dictamina recursos de reconsideración (confirma, modifica o revoca sanción) y ordena reposición de procedimiento por violación a derechos humanos.

Cap. III. Faltas y sanciones (Arts. 100-115):
- Art. 100 (Faltas no graves): I. Interrumpir clase o actividades sin autorización; II. Impuntualidad reiterada; III. Usar dispositivos electrónicos con fines distintos al proceso de enseñanza-aprendizaje; IV. Mal uso de biblioteca, labs y salas de cómputo según sus lineamientos; V. Otras que juzgue el Consejo Operativo Escolar.
- Art. 101 (Faltas graves): I. Agredir física, verbal, no verbal, sexual, económica o psicológicamente (presencial o virtual); II. Actos de carácter sexual dentro del plantel; III. Actos sexuales en entornos virtuales/redes del Colegio; IV. Capturar, editar, publicar o difundir texto/imagen/audio/video que dañe la dignidad; V. Amenazar o extorsionar (individual o en grupos); VI. Dañar o sustraer bienes de la comunidad; VII. Incitar o provocar violencia; VIII. Portar o usar armas, explosivos u objetos peligrosos; IX. Poseer, distribuir o consumir medicamentos controlados sin receta, drogas ilegales, alcohol, tabaco, cigarros electrónicos o vapeadores; X. Ingresar ebrio o bajo efectos de droga (salvo prescripción); XI. Sustraer, malgastar o dañar intencionalmente patrimonio del Colegio; XII. Dar o recibir ayuda fraudulenta en evaluaciones; XIII. Copiar, plagiar o falsificar obras o evidencias ajenas; XIV. Documentos o declaraciones falsas en trámites; XV. Suplantar o dejarse suplantar en actividades académicas o administrativas; XVI. Alterar registros físicos o digitales del Colegio (certificado, historia, comprobante, credencial); XVII. Otras que afecten gravemente o juzgue el Consejo Operativo Escolar.
- Art. 102: Toda falta que amerite Consejo Operativo sigue el "Procedimiento de investigación para el estudiantado presuntamente infractor".
- Art. 103-109 (Sanciones por faltas no graves, además de reparación del daño):
  I. Apercibimiento verbal (Art. 104: Dirección, Subdirección, Jefaturas o personal).
  II. Amonestación por escrito (Art. 105: Consejo Operativo/Ejecutivo; notifica a tutor si es menor; contiene datos, descripción, afectados, firmas y fundamentación).
  III. Actividades en favor de la comunidad (Art. 106-107: cuando teniendo amonestación por escrito reincida; máximo 2 horas continuas por día, máximo 2 días por semana, fuera de horario de clases, bajo supervisión; opciones: fortalecer campaña de convivencia, exponer tema, reforestación/áreas verdes, propuesta propia u otras pertinentes).
  - Art. 108: Reincidir después de haber cumplido una sanción no admite repetir la misma y se considera falta grave.
  - Art. 109: Mediación para acordar reparación del daño en faltas no graves.
- Art. 110-115 (Sanciones por faltas graves, además de reparación del daño):
  I. Suspensión temporal desde 1 día hábil hasta 1 año (Art. 112: no puede usar servicio educativo de ninguna modalidad durante ese tiempo; aplica máximo 2 ocasiones y cuenta en la vigencia de matrícula).
  II. Suspensión definitiva (Art. 113: a la 3a reincidencia tras suspensión temporal; Art. 114: en escolarizada se ofrece continuar en modalidad no escolarizada o en otro servicio educativo; en no escolarizada se ofrece otro servicio educativo).
  - Art. 115: Faltas graves o actos que causen perjuicio se hacen del conocimiento de instancias competentes con Unidad de Apoyo Jurídico y se turnan a autoridad judicial.

=====================================================================
DOCUMENTO 2: LINEAMIENTOS DEL BACHILLERATO EN LÍNEA, OPCIÓN EDUCATIVA VIRTUAL (2018)
Código: DASE-SOE-DSEA-LI-01-ENERO-2018
=====================================================================
- Generales: Basado en Modelo Pedagógico de la Modalidad no Escolarizada y Plan de Estudios 92. Evaluaciones exclusivamente en Centros de Evaluación Autorizados (CEA) bajo supervisión de aplicador autorizado y registrado por CB.
- Ingreso:
  - Registro exclusivo en www.colbachenlinea.mx en la opción "Regístrate".
  - Documentos y datos: Certificado de Secundaria, Acta de Nacimiento, CURP, Fotografía digital, Historial académico del CB (si estudios parciales en CB), Certificado parcial y solicitud de ingreso por equivalencia en formato de inscripción (si estudios parciales en otra institución).
  - Estatus: Ingreso (folio y contraseña), Cambio de sistema (folio y contraseña), Equivalencia (matrícula y contraseña + trámite de dictamen), Transitabilidad (planes posteriores al Plan 92, folio y contraseña + trámite).
  - Archivos electrónicos: acta de nacimiento, certificado de secundaria, certificado parcial de procedencia. Al aceptarse, llega matrícula y contraseña por correo.
- Permanencia y Evaluaciones:
  - Selecciona asignatura(s), paga en cuenta bancaria señalada en plataforma y espera 2 días hábiles para acceder al material multimedia (pago único).
  - Al terminar contenidos, paga el costo del examen global en banco designado, espera 2 días hábiles y elige CEA, día y hora.
  - Si no acredita el examen global, debe presentar examen por cada uno de los fascículos que integran la asignatura.
  - En el CEA debe presentar identificación oficial vigente con fotografía (el aplicador la retiene durante la aplicación y la devuelve al final).
  - Límite mensual: máximo 4 exámenes globales y 8 fasciculares por mes calendario (no combinables para sumar 12). Excepción: con 80% de avance académico y casos de fuerza mayor (apoyo al egreso), solicitar autorización vía oficio firmado por responsable operativo con respaldo a la SOE por correo electrónico (respuesta en máx 2 días hábiles).
  - Reagendar: si no se presenta el día agendado, puede reagendar dentro del mismo año calendario en que realizó el pago; de lo contrario, debe volver a pagar.
  - Apoyo permitido: únicamente calculadora no científica.
  - Prohibido durante el examen: teléfonos celulares, memorias USB, grabadoras, cámaras fotográficas, libros, apuntes, formularios no autorizados -> sanción desde suspensión temporal hasta baja definitiva del sistema.
  - Reactivación de examen: procede por fallas de energía eléctrica o conectividad a Internet en el CEA. Si la falla no excede 30 minutos se respeta el avance; si excede 30 minutos realiza nuevo examen en plazo máximo de 10 días hábiles (el aplicador reporta el mismo día con datos del alumno, examen, CEA y motivo).
  - El CB puede anular resultados por irregularidades y realizar supervisión sin previo aviso.
- Egreso:
  - Al concluir todas las asignaturas, tramita certificado enviando correo a: certificado.terminacion@bachilleratosead.net
  - Documentos: Certificado de secundaria, Acta de nacimiento, Ficha de depósito bancario (servicio y envío), Fotografía.
  - Información: CURP, Nombre completo, Matrícula en el CB, Servicio solicitado (Certificado Parcial, Terminación o Duplicado), Teléfono, Domicilio actual (Estado y Municipio).
  - El área de certificación valida en 3 días hábiles e informa fecha aproximada de emisión y envío. Al recibirlo, el estudiante revisa datos y firma; si hay error notifica para corrección.
""".trimIndent()
}
