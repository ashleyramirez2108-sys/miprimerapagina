package com.example.data

import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.ai.Chat
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout

private const val TAG = "ColbachAssistantRepo"
private const val MODEL_NAME = "gemini-3.8-flash"
private const val REQUEST_TIMEOUT_MS = 60_000L

class ColbachAssistantRepository {

    private val model by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_NAME,
            generationConfig = generationConfig {
                temperature = 0.2f
            },
            systemInstruction = content {
                text(ColbachKnowledgeBase.buildSystemInstruction())
            },
        )
    }

    private var chatSession: Chat? = null

    private fun getOrCreateChat(): Chat {
        return chatSession ?: model.startChat().also { chatSession = it }
    }

    fun resetSession() {
        chatSession = null
    }

    fun sendMessageStream(
        question: String,
        modality: StudyModality,
    ): Flow<String> = flow {
        val contextualPrompt = buildString {
            append("[Contexto de modalidad: ")
            append(modality.promptContext)
            append("]\n\n")
            append("Pregunta del estudiante: ")
            append(question.trim())
        }

        try {
            val chat = getOrCreateChat()
            val accumulated = StringBuilder()
            withTimeout(REQUEST_TIMEOUT_MS) {
                chat.sendMessageStream(contextualPrompt).collect { chunk ->
                    val chunkText = chunk.text.orEmpty()
                    if (chunkText.isNotEmpty()) {
                        accumulated.append(chunkText)
                        emit(accumulated.toString())
                    }
                }
            }
            if (accumulated.isBlank()) {
                throw IllegalStateException(
                    "El asistente no devolvió contenido. Por favor, intenta reformular tu duda."
                )
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Error streaming response from Firebase AI Logic", e)
            throw e
        }
    }
}
