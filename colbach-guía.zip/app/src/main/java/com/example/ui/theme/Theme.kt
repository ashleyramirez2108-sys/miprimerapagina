package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private val LightColorScheme = lightColorScheme(
    primary = ColbachNavy,
    onPrimary = Color.White,
    primaryContainer = ColbachNavyContainer,
    onPrimaryContainer = OnColbachNavyContainer,
    secondary = ColbachBurgundy,
    onSecondary = Color.White,
    secondaryContainer = ColbachBurgundyContainer,
    onSecondaryContainer = OnColbachBurgundyContainer,
    tertiary = ColbachGold,
    onTertiary = Color.White,
    tertiaryContainer = ColbachGoldContainer,
    onTertiaryContainer = OnColbachGoldContainer,
    background = ColbachIvory,
    onBackground = ColbachTextPrimary,
    surface = ColbachSurfaceWhite,
    onSurface = ColbachTextPrimary,
    surfaceVariant = ColbachSurfaceWarm,
    onSurfaceVariant = ColbachTextSecondary,
    surfaceContainerLow = ColbachIvory,
    surfaceContainer = ColbachSurfaceWarm,
    surfaceContainerHigh = Color(0xFFEAE4DA),
    outline = ColbachOutline,
    outlineVariant = ColbachOutlineVariant,
    error = StatusError,
    onError = Color.White,
    errorContainer = StatusErrorContainer,
    onErrorContainer = Color(0xFF410E0B),
)

private val DarkColorScheme = darkColorScheme(
    primary = ColbachNavyDark,
    onPrimary = OnColbachNavyDark,
    primaryContainer = ColbachNavyContainerDark,
    onPrimaryContainer = OnColbachNavyContainerDark,
    secondary = ColbachBurgundyDark,
    onSecondary = OnColbachBurgundyDark,
    secondaryContainer = ColbachBurgundyContainerDark,
    onSecondaryContainer = OnColbachBurgundyContainerDark,
    tertiary = ColbachGoldDark,
    onTertiary = OnColbachGoldDark,
    tertiaryContainer = ColbachGoldContainerDark,
    onTertiaryContainer = OnColbachGoldContainerDark,
    background = ColbachDarkBackground,
    onBackground = ColbachDarkTextPrimary,
    surface = ColbachDarkSurface,
    onSurface = ColbachDarkTextPrimary,
    surfaceVariant = ColbachDarkSurfaceVariant,
    onSurfaceVariant = ColbachDarkTextSecondary,
    surfaceContainerLow = ColbachDarkSurface,
    surfaceContainer = ColbachDarkSurfaceVariant,
    surfaceContainerHigh = Color(0xFF263342),
    outline = ColbachDarkOutline,
    outlineVariant = ColbachDarkOutlineVariant,
    error = Color(0xFFF2B8B5),
    onError = Color(0xFF601410),
    errorContainer = Color(0xFF8C1D18),
    onErrorContainer = Color(0xFFF9DEDC),
)

val ColbachShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun ColbachTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = ColbachShapes,
        content = content,
    )
}
