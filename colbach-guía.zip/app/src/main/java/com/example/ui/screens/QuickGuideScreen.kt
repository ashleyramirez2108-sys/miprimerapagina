package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Calculate
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Gavel
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.StudyModality
import com.example.ui.ColbachUiState
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusErrorContainer
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusSuccessContainer
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.StatusWarningContainer

@Composable
fun QuickGuideScreen(
    uiState: ColbachUiState,
    onGradeChanged: (String) -> Unit,
    onAttendanceChanged: (String) -> Unit,
    onAskQuestion: (String, StudyModality) -> Unit,
    modifier: Modifier = Modifier,
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            GradeCalculatorCard(
                uiState = uiState,
                onGradeChanged = onGradeChanged,
                onAttendanceChanged = onAttendanceChanged,
            )
        }
        item {
            PermanenceTrafficLightCard(
                onAskQuestion = onAskQuestion,
            )
        }
        item {
            ConductSummaryCard(
                onAskQuestion = onAskQuestion,
            )
        }
    }
}

@Composable
private fun GradeCalculatorCard(
    uiState: ColbachUiState,
    onGradeChanged: (String) -> Unit,
    onAttendanceChanged: (String) -> Unit,
) {
    val result = uiState.gradeResult
    val (statusBg, statusFg) = when {
        result.finalGrade == null && !result.isWStatus ->
            MaterialTheme.colorScheme.surfaceVariant to MaterialTheme.colorScheme.onSurfaceVariant
        result.isApproved -> StatusSuccessContainer to StatusSuccess
        result.isWStatus -> StatusWarningContainer to StatusWarning
        else -> StatusErrorContainer to StatusError
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Calculate,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                }
                Column {
                    Text(
                        text = "Calculadora de Acreditación",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                        text = "Artículos 49, 51 y 52 · Reglamento 2025",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.secondary,
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                OutlinedTextField(
                    value = uiState.partialGradeInput,
                    onValueChange = onGradeChanged,
                    label = { Text("Promedio (0.0 - 10)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("calc_grade_input"),
                )
                OutlinedTextField(
                    value = uiState.attendanceInput,
                    onValueChange = onAttendanceChanged,
                    label = { Text("Asistencia (%)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("calc_attendance_input"),
                )
            }

            Surface(
                color = statusBg,
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("calc_result_card"),
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Icon(
                            imageVector = if (result.isApproved) Icons.Outlined.CheckCircle
                            else Icons.Outlined.WarningAmber,
                            contentDescription = null,
                            tint = statusFg,
                            modifier = Modifier.size(20.dp),
                        )
                        Text(
                            text = result.statusLabel,
                            style = MaterialTheme.typography.titleMedium,
                            color = statusFg,
                        )
                    }
                    Text(
                        text = result.explanation,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                        text = result.legalReference,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            Text(
                text = "Tabla oficial de conversión (Art. 49)",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            val ranges = listOf(
                "9.6 – 10.0" to "10 (Acreditado)",
                "8.6 – 9.5" to "9 (Acreditado)",
                "7.6 – 8.5" to "8 (Acreditado)",
                "6.6 – 7.5" to "7 (Acreditado)",
                "6.0 – 6.5" to "6 (Acreditado)",
                "0.0 – 5.9" to "5 (No acreditado)",
            )
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                ranges.chunked(2).forEach { pair ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        pair.forEach { (range, label) ->
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceContainerLow,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f),
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    Text(
                                        text = range,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.primary,
                                    )
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                                        color = MaterialTheme.colorScheme.onSurface,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PermanenceTrafficLightCard(
    onAskQuestion: (String, StudyModality) -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.tertiaryContainer),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Schedule,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onTertiaryContainer,
                    )
                }
                Column {
                    Text(
                        text = "Permanencia y Plazos Máximos",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                        text = "Artículos 15, 18, 25, 26 y 28",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.secondary,
                    )
                }
            }

            InfoHighlightRow(
                badge = "0 a 4 adeudos",
                badgeColor = StatusSuccessContainer,
                badgeTextColor = StatusSuccess,
                description = "Puedes continuar o reincorporarte en Escolarizada si la vigencia de tu matrícula lo permite (Art. 15 y 21).",
            )
            InfoHighlightRow(
                badge = "5+ adeudos",
                badgeColor = StatusErrorContainer,
                badgeTextColor = StatusError,
                description = "Causa baja temporal institucional en Escolarizada hasta regularizarte; no extiende tu vigencia (Art. 15 y 19).",
            )
            InfoHighlightRow(
                badge = "Vigencia máx.",
                badgeColor = MaterialTheme.colorScheme.primaryContainer,
                badgeTextColor = MaterialTheme.colorScheme.onPrimaryContainer,
                description = "Escolarizada: 3 a 6 años. No Escolarizada / En Línea: 2 a 6 años desde la 1ra materia acreditada, sin prórroga (Art. 28).",
            )
            InfoHighlightRow(
                badge = "En Línea / SEA",
                badgeColor = MaterialTheme.colorScheme.secondaryContainer,
                badgeTextColor = MaterialTheme.colorScheme.onSecondaryContainer,
                description = "Acreditar mín. 1 evaluación cada 2 meses (Art. 26). Límite mensual: 4 globales y 8 fasciculares (Art. 25 y Lineamientos 2018).",
            )

            OutlinedButton(
                onClick = {
                    onAskQuestion(
                        "¿Cuáles son los mecanismos de regularización disponibles si reprobé materias y cómo puedo reincorporarme?",
                        StudyModality.TODAS,
                    )
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .testTag("guide_ask_regularizacion"),
            ) {
                Icon(
                    imageVector = Icons.Outlined.AutoAwesome,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Consultar sobre regularización")
            }
        }
    }
}

@Composable
private fun ConductSummaryCard(
    onAskQuestion: (String, StudyModality) -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.secondaryContainer),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Gavel,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSecondaryContainer,
                    )
                }
                Column {
                    Text(
                        text = "Convivencia, Sanciones y Defensa",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                        text = "Artículos 96 y 100 al 115 · Reglamento 2025",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.secondary,
                    )
                }
            }

            InfoHighlightRow(
                badge = "Falta no grave",
                badgeColor = StatusWarningContainer,
                badgeTextColor = StatusWarning,
                description = "Apercibimiento verbal, amonestación por escrito o actividades en favor de la comunidad (máx. 2 hrs/día, 2 días/semana) y mediación (Arts. 103–109).",
            )
            InfoHighlightRow(
                badge = "Falta grave",
                badgeColor = StatusErrorContainer,
                badgeTextColor = StatusError,
                description = "Suspensión temporal (1 día hábil a 1 año, máx. 2 veces) o suspensión definitiva (Arts. 110–114).",
            )
            InfoHighlightRow(
                badge = "Reconsideración",
                badgeColor = MaterialTheme.colorScheme.primaryContainer,
                badgeTextColor = MaterialTheme.colorScheme.onPrimaryContainer,
                description = "Tienes derecho a inconformarte por escrito ante el Consejo Ejecutivo Escolar dentro de los 10 días hábiles siguientes a la notificación (Art. 96 IV).",
            )

            OutlinedButton(
                onClick = {
                    onAskQuestion(
                        "¿Cómo funciona el recurso de reconsideración si recibo una sanción del Consejo Operativo Escolar?",
                        StudyModality.TODAS,
                    )
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .testTag("guide_ask_reconsideracion"),
            ) {
                Icon(
                    imageVector = Icons.Outlined.AutoAwesome,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Preguntar sobre derechos y defensa")
            }
        }
    }
}

@Composable
private fun InfoHighlightRow(
    badge: String,
    badgeColor: androidx.compose.ui.graphics.Color,
    badgeTextColor: androidx.compose.ui.graphics.Color,
    description: String,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Surface(
            color = badgeColor,
            shape = RoundedCornerShape(8.dp),
        ) {
            Text(
                text = badge,
                style = MaterialTheme.typography.labelSmall,
                color = badgeTextColor,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
            )
        }
        Text(
            text = description,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f),
        )
    }
}
