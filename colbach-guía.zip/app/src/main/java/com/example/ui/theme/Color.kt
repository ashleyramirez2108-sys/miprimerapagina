package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// COLBACH Institutional Light Palette
val ColbachNavy = Color(0xFF0B2D4D)
val ColbachNavyLight = Color(0xFF1A4670)
val ColbachNavyContainer = Color(0xFFD6E4F5)
val OnColbachNavyContainer = Color(0xFF061B33)

val ColbachBurgundy = Color(0xFF7A1C33)
val ColbachBurgundyContainer = Color(0xFFFCE4EA)
val OnColbachBurgundyContainer = Color(0xFF3E0817)

val ColbachGold = Color(0xFFB4761A)
val ColbachGoldContainer = Color(0xFFFBEFD6)
val OnColbachGoldContainer = Color(0xFF382100)

val ColbachIvory = Color(0xFFFAF8F5)
val ColbachSurfaceWhite = Color(0xFFFFFFFF)
val ColbachSurfaceWarm = Color(0xFFF3EFE8)
val ColbachOutline = Color(0xFF837B70)
val ColbachOutlineVariant = Color(0xFFDDD6CA)
val ColbachTextPrimary = Color(0xFF171C22)
val ColbachTextSecondary = Color(0xFF4F565E)

// Semantic status colors
val StatusSuccess = Color(0xFF1B7A54)
val StatusSuccessContainer = Color(0xFFD9F3E7)
val StatusWarning = Color(0xFFB86B00)
val StatusWarningContainer = Color(0xFFFFEED2)
val StatusError = Color(0xFFB3261E)
val StatusErrorContainer = Color(0xFFF9DEDC)

// COLBACH Institutional Dark Palette
val ColbachNavyDark = Color(0xFF8BB8E8)
val OnColbachNavyDark = Color(0xFF07233E)
val ColbachNavyContainerDark = Color(0xFF123D66)
val OnColbachNavyContainerDark = Color(0xFFD6E4F5)

val ColbachBurgundyDark = Color(0xFFE892A5)
val OnColbachBurgundyDark = Color(0xFF4A0D1D)
val ColbachBurgundyContainerDark = Color(0xFF65162B)
val OnColbachBurgundyContainerDark = Color(0xFFFCE4EA)

val ColbachGoldDark = Color(0xFFE5B567)
val OnColbachGoldDark = Color(0xFF3E2600)
val ColbachGoldContainerDark = Color(0xFF5A3900)
val OnColbachGoldContainerDark = Color(0xFFFBEFD6)

val ColbachDarkBackground = Color(0xFF0E141B)
val ColbachDarkSurface = Color(0xFF151D26)
val ColbachDarkSurfaceVariant = Color(0xFF1F2A36)
val ColbachDarkOutline = Color(0xFF8D98A5)
val ColbachDarkOutlineVariant = Color(0xFF2E3C4B)
val ColbachDarkTextPrimary = Color(0xFFEDF1F5)
val ColbachDarkTextSecondary = Color(0xFFB2BCC7)
