package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/**
 * Lightweight Compose renderer for structured Spanish responses:
 * supports **bold**, *italic*, bullet lists (- / * / •), numbered lists (1. ),
 * and highlighted official reference lines.
 */
@Composable
fun FormattedAssistantText(
    text: String,
    textColor: Color = MaterialTheme.colorScheme.onSurface,
    modifier: Modifier = Modifier,
) {
    val lines = text.lines()
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        lines.forEach { rawLine ->
            val trimmed = rawLine.trim()
            when {
                trimmed.isEmpty() -> Unit
                trimmed.startsWith("* ") || trimmed.startsWith("- ") || trimmed.startsWith("• ") -> {
                    val bulletContent = trimmed.drop(2).trim()
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.Top,
                    ) {
                        Box(
                            modifier = Modifier
                                .padding(top = 8.dp)
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.secondary)
                        )
                        Text(
                            text = parseInlineFormatting(bulletContent),
                            style = MaterialTheme.typography.bodyLarge,
                            color = textColor,
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
                isNumberedListItem(trimmed) -> {
                    val dotIndex = trimmed.indexOf('.')
                    val numberPrefix = trimmed.substring(0, dotIndex + 1)
                    val content = trimmed.substring(dotIndex + 1).trim()
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.Top,
                    ) {
                        Text(
                            text = numberPrefix,
                            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary,
                        )
                        Text(
                            text = parseInlineFormatting(content),
                            style = MaterialTheme.typography.bodyLarge,
                            color = textColor,
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
                trimmed.startsWith("### ") || trimmed.startsWith("## ") || trimmed.startsWith("# ") -> {
                    val heading = trimmed.trimStart('#', ' ')
                    Text(
                        text = parseInlineFormatting(heading),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 4.dp),
                    )
                }
                isReferenceLine(trimmed) -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.65f))
                            .padding(horizontal = 10.dp, vertical = 7.dp),
                    ) {
                        Text(
                            text = parseInlineFormatting(trimmed.removeSurrounding("(", ")")),
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.onTertiaryContainer,
                        )
                    }
                }
                else -> {
                    Text(
                        text = parseInlineFormatting(trimmed),
                        style = MaterialTheme.typography.bodyLarge,
                        color = textColor,
                    )
                }
            }
        }
    }
}

private fun isNumberedListItem(line: String): Boolean {
    val dotIndex = line.indexOf('.')
    if (dotIndex !in 1..3) return false
    val prefix = line.substring(0, dotIndex)
    return prefix.all { it.isDigit() } && line.getOrNull(dotIndex + 1) == ' '
}

private fun isReferenceLine(line: String): Boolean {
    val lower = line.lowercase()
    return lower.startsWith("*(referencia") ||
        lower.startsWith("(referencia") ||
        lower.startsWith("referencia:") ||
        lower.startsWith("**referencia") ||
        lower.startsWith("*basado en") ||
        lower.startsWith("basado en el artículo")
}

private fun parseInlineFormatting(input: String): AnnotatedString = buildAnnotatedString {
    var index = 0
    while (index < input.length) {
        if (input.startsWith("**", index)) {
            val end = input.indexOf("**", index + 2)
            if (end != -1) {
                val boldText = input.substring(index + 2, end)
                pushStyle(SpanStyle(fontWeight = FontWeight.Bold))
                append(boldText)
                pop()
                index = end + 2
                continue
            }
        }
        if (input[index] == '*' && !input.startsWith("**", index)) {
            val end = input.indexOf('*', index + 1)
            if (end != -1) {
                val italicText = input.substring(index + 1, end)
                pushStyle(SpanStyle(fontStyle = FontStyle.Italic))
                append(italicText)
                pop()
                index = end + 1
                continue
            }
        }
        append(input[index])
        index++
    }
}
