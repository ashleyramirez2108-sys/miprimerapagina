package com.example.ui

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppTab
import com.example.data.ChatMessage
import com.example.data.ColbachAssistantRepository
import com.example.data.ColbachKnowledgeBase
import com.example.data.GradeCalculationResult
import com.example.data.NormativaEntry
import com.example.data.NormativaSource
import com.example.data.QuickPrompt
import com.example.data.StudyModality
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

private const val TAG = "ColbachViewModel"

sealed interface AssistantUiState {
    data object Idle : AssistantUiState
    data object Loading : AssistantUiState
    data class Streaming(val text: String) : AssistantUiState
    data class Error(val message: String, val retryPrompt: String) : AssistantUiState
}

data class ColbachUiState(
    val currentTab: AppTab = AppTab.ASISTENTE,
    val selectedModality: StudyModality = StudyModality.TODAS,
    val inputText: String = "",
    val messages: List<ChatMessage> = emptyList(),
    val assistantState: AssistantUiState = AssistantUiState.Idle,
    val quickPrompts: List<QuickPrompt> = ColbachKnowledgeBase.quickPrompts,
    val searchQuery: String = "",
    val selectedNormativaSource: NormativaSource = NormativaSource.ALL,
    val filteredNormativa: List<NormativaEntry> = ColbachKnowledgeBase.normativaEntries,
    val expandedNormativaId: String? = ColbachKnowledgeBase.normativaEntries.firstOrNull()?.id,
    val partialGradeInput: String = "8.5",
    val attendanceInput: String = "90",
    val gradeResult: GradeCalculationResult = ColbachKnowledgeBase.evaluateGradeAndAttendance(8.5, 90),
)

class ColbachViewModel(
    private val repository: ColbachAssistantRepository = ColbachAssistantRepository(),
) : ViewModel() {

    private val _uiState = MutableStateFlow(ColbachUiState())
    val uiState: StateFlow<ColbachUiState> = _uiState.asStateFlow()

    private var activeStreamJob: Job? = null

    fun selectTab(tab: AppTab) {
        _uiState.update { it.copy(currentTab = tab) }
    }

    fun selectModality(modality: StudyModality) {
        _uiState.update { it.copy(selectedModality = modality) }
    }

    fun updateInputText(text: String) {
        _uiState.update { it.copy(inputText = text) }
    }

    fun resetConversation() {
        activeStreamJob?.cancel()
        repository.resetSession()
        _uiState.update {
            it.copy(
                messages = emptyList(),
                inputText = "",
                assistantState = AssistantUiState.Idle,
            )
        }
    }

    fun askFromNormativa(entry: NormativaEntry) {
        val suggestedModality = if (entry.source == NormativaSource.BACHILLERATO_EN_LINEA_2018) {
            StudyModality.EN_LINEA
        } else {
            _uiState.value.selectedModality
        }
        val question = "Explícame de forma sencilla qué dice el apartado \"${entry.title}\" (${entry.reference}) y cómo aplica para mí."
        _uiState.update {
            it.copy(
                currentTab = AppTab.ASISTENTE,
                selectedModality = suggestedModality,
            )
        }
        sendMessage(question)
    }

    fun askDirectQuestion(question: String, modality: StudyModality = _uiState.value.selectedModality) {
        _uiState.update {
            it.copy(
                currentTab = AppTab.ASISTENTE,
                selectedModality = modality,
            )
        }
        sendMessage(question)
    }

    fun sendMessage(overridePrompt: String? = null) {
        val prompt = (overridePrompt ?: _uiState.value.inputText).trim()
        if (prompt.isEmpty()) return

        val currentModality = _uiState.value.selectedModality
        val userMessage = ChatMessage(
            id = UUID.randomUUID().toString(),
            isUser = true,
            text = prompt,
        )

        activeStreamJob?.cancel()
        _uiState.update { state ->
            state.copy(
                inputText = if (overridePrompt == null) "" else state.inputText,
                messages = state.messages + userMessage,
                assistantState = AssistantUiState.Loading,
            )
        }

        activeStreamJob = viewModelScope.launch {
            var latestText = ""
            try {
                repository.sendMessageStream(prompt, currentModality).collect { partial ->
                    latestText = partial
                    _uiState.update { it.copy(assistantState = AssistantUiState.Streaming(partial)) }
                }

                if (latestText.isNotBlank()) {
                    val assistantMessage = ChatMessage(
                        id = UUID.randomUUID().toString(),
                        isUser = false,
                        text = latestText,
                    )
                    _uiState.update { state ->
                        state.copy(
                            messages = state.messages + assistantMessage,
                            assistantState = AssistantUiState.Idle,
                        )
                    }
                } else {
                    _uiState.update {
                        it.copy(
                            assistantState = AssistantUiState.Error(
                                message = "El modelo devolvió una respuesta vacía.",
                                retryPrompt = prompt,
                            )
                        )
                    }
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "AI generation timed out", e)
                _uiState.update {
                    it.copy(
                        assistantState = AssistantUiState.Error(
                            message = "La consulta tardó más de 60 segundos. Verifica tu conexión e inténtalo de nuevo.",
                            retryPrompt = prompt,
                        )
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "AI generation failed", e)
                _uiState.update {
                    it.copy(
                        assistantState = AssistantUiState.Error(
                            message = e.localizedMessage
                                ?: "No se pudo conectar con el Asistente Virtual. Revisa tu conexión a internet.",
                            retryPrompt = prompt,
                        )
                    )
                }
            }
        }
    }

    fun retryLastFailedPrompt() {
        val errorState = _uiState.value.assistantState as? AssistantUiState.Error ?: return
        val promptToRetry = errorState.retryPrompt
        // Remove the trailing user message if it matches the failed prompt so it isn't duplicated
        _uiState.update { state ->
            val trimmedMessages = if (state.messages.lastOrNull()?.let { it.isUser && it.text == promptToRetry } == true) {
                state.messages.dropLast(1)
            } else {
                state.messages
            }
            state.copy(messages = trimmedMessages, assistantState = AssistantUiState.Idle)
        }
        sendMessage(promptToRetry)
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { state ->
            val filtered = filterEntries(query, state.selectedNormativaSource)
            state.copy(searchQuery = query, filteredNormativa = filtered)
        }
    }

    fun selectNormativaSource(source: NormativaSource) {
        _uiState.update { state ->
            val filtered = filterEntries(state.searchQuery, source)
            state.copy(selectedNormativaSource = source, filteredNormativa = filtered)
        }
    }

    fun toggleNormativaExpanded(entryId: String) {
        _uiState.update { state ->
            state.copy(
                expandedNormativaId = if (state.expandedNormativaId == entryId) null else entryId
            )
        }
    }

    fun updateGradeInputs(partialText: String? = null, attendanceText: String? = null) {
        _uiState.update { state ->
            val nextGradeText = partialText ?: state.partialGradeInput
            val nextAttText = attendanceText ?: state.attendanceInput
            val parsedGrade = nextGradeText.replace(",", ".").toDoubleOrNull()
            val parsedAtt = nextAttText.trim().toIntOrNull()
            state.copy(
                partialGradeInput = nextGradeText,
                attendanceInput = nextAttText,
                gradeResult = ColbachKnowledgeBase.evaluateGradeAndAttendance(parsedGrade, parsedAtt),
            )
        }
    }

    private fun filterEntries(query: String, source: NormativaSource): List<NormativaEntry> {
        val normalizedQuery = query.trim().lowercase()
        return ColbachKnowledgeBase.normativaEntries.filter { entry ->
            val matchesSource = source == NormativaSource.ALL || entry.source == source
            val matchesQuery = normalizedQuery.isEmpty() ||
                entry.title.lowercase().contains(normalizedQuery) ||
                entry.reference.lowercase().contains(normalizedQuery) ||
                entry.summary.lowercase().contains(normalizedQuery) ||
                entry.details.any { it.lowercase().contains(normalizedQuery) } ||
                entry.tags.any { it.lowercase().contains(normalizedQuery) }
            matchesSource && matchesQuery
        }
    }
}
