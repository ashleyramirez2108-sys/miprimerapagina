package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.outlined.AddComment
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Calculate
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.R
import com.example.data.AppTab
import com.example.ui.screens.AssistantScreen
import com.example.ui.screens.NormativaScreen
import com.example.ui.screens.QuickGuideScreen
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ColbachApp(
    viewModel: ColbachViewModel = viewModel(),
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val copiedToastText = stringResource(R.string.copied_toast)

    BackHandler(enabled = uiState.currentTab != AppTab.ASISTENTE) {
        viewModel.selectTab(AppTab.ASISTENTE)
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavigationRail = maxWidth >= 600.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = MaterialTheme.colorScheme.background,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.img_assistant_avatar),
                                contentDescription = stringResource(R.string.assistant_avatar_desc),
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape),
                            )
                            Column {
                                Text(
                                    text = stringResource(R.string.app_name),
                                    style = MaterialTheme.typography.titleLarge,
                                    color = MaterialTheme.colorScheme.onPrimary,
                                )
                                Text(
                                    text = stringResource(R.string.app_subtitle),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.82f),
                                )
                            }
                        }
                    },
                    actions = {
                        if (uiState.currentTab == AppTab.ASISTENTE && uiState.messages.isNotEmpty()) {
                            IconButton(
                                onClick = { viewModel.resetConversation() },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("new_chat_button"),
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.AddComment,
                                    contentDescription = stringResource(R.string.new_chat_desc),
                                    tint = MaterialTheme.colorScheme.onPrimary,
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                    ),
                )
            },
            bottomBar = {
                if (!useNavigationRail) {
                    NavigationBar(
                        windowInsets = WindowInsets.navigationBars,
                        containerColor = MaterialTheme.colorScheme.surface,
                    ) {
                        AppTab.entries.forEach { tab ->
                            val selected = uiState.currentTab == tab
                            NavigationBarItem(
                                selected = selected,
                                onClick = { viewModel.selectTab(tab) },
                                icon = {
                                    Icon(
                                        imageVector = tabIcon(tab, selected),
                                        contentDescription = null,
                                    )
                                },
                                label = {
                                    Text(
                                        text = tabLabel(tab),
                                        style = MaterialTheme.typography.labelMedium,
                                    )
                                },
                                modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}"),
                            )
                        }
                    }
                }
            },
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
            ) {
                if (useNavigationRail) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxHeight(),
                    ) {
                        AppTab.entries.forEach { tab ->
                            val selected = uiState.currentTab == tab
                            NavigationRailItem(
                                selected = selected,
                                onClick = { viewModel.selectTab(tab) },
                                icon = {
                                    Icon(
                                        imageVector = tabIcon(tab, selected),
                                        contentDescription = null,
                                    )
                                },
                                label = { Text(text = tabLabel(tab)) },
                                modifier = Modifier.testTag("rail_tab_${tab.name.lowercase()}"),
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    contentAlignment = Alignment.TopCenter,
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .widthIn(max = 800.dp),
                    ) {
                        when (uiState.currentTab) {
                            AppTab.ASISTENTE -> AssistantScreen(
                                uiState = uiState,
                                onModalitySelected = viewModel::selectModality,
                                onInputChanged = viewModel::updateInputText,
                                onSendClicked = { viewModel.sendMessage() },
                                onQuickPromptClicked = { question ->
                                    viewModel.askDirectQuestion(question)
                                },
                                onRetryClicked = viewModel::retryLastFailedPrompt,
                                onMessageCopied = {
                                    scope.launch {
                                        snackbarHostState.showSnackbar(copiedToastText)
                                    }
                                },
                            )
                            AppTab.NORMATIVA -> NormativaScreen(
                                uiState = uiState,
                                onSearchChanged = viewModel::updateSearchQuery,
                                onSourceSelected = viewModel::selectNormativaSource,
                                onToggleExpanded = viewModel::toggleNormativaExpanded,
                                onAskAboutEntry = viewModel::askFromNormativa,
                                onAskCustomSearch = { question ->
                                    viewModel.askDirectQuestion(question)
                                },
                            )
                            AppTab.GUIA -> QuickGuideScreen(
                                uiState = uiState,
                                onGradeChanged = { grade ->
                                    viewModel.updateGradeInputs(partialText = grade)
                                },
                                onAttendanceChanged = { att ->
                                    viewModel.updateGradeInputs(attendanceText = att)
                                },
                                onAskQuestion = viewModel::askDirectQuestion,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun tabLabel(tab: AppTab): String = when (tab) {
    AppTab.ASISTENTE -> stringResource(R.string.nav_assistant)
    AppTab.NORMATIVA -> stringResource(R.string.nav_regulations)
    AppTab.GUIA -> stringResource(R.string.nav_guide)
}

private fun tabIcon(tab: AppTab, selected: Boolean) = when (tab) {
    AppTab.ASISTENTE -> if (selected) Icons.Filled.AutoAwesome else Icons.Outlined.AutoAwesome
    AppTab.NORMATIVA -> if (selected) Icons.Filled.MenuBook else Icons.Outlined.MenuBook
    AppTab.GUIA -> if (selected) Icons.Filled.Calculate else Icons.Outlined.Calculate
}
