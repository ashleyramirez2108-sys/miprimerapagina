import 'dotenv/config';
import express from 'express';
import fs from 'fs';
import path from 'path';
import QRCode from 'qrcode';

const app = express();
app.set('trust proxy', true);           // necesario detrás del HTTPS del hosting
app.use(express.json({ limit: '50kb' }));

const { ANTHROPIC_API_KEY, MODEL = 'claude-sonnet-5-5', APP_URL, RENDER_EXTERNAL_URL, PORT = 3000 } = process.env;
const DAILY_LIMIT = parseInt(process.env.DAILY_LIMIT) || 1000;
if (!ANTHROPIC_API_KEY) console.warn('⚠️  Falta ANTHROPIC_API_KEY: el chat no podrá responder.');

// ---- Conocimiento: todos los .md de /knowledge (reglamento + lineamientos) ----
const CONOCIMIENTO = fs.readdirSync('knowledge').filter(f => f.endsWith('.md')).sort()
  .map(f => fs.readFileSync(`knowledge/${f}`, 'utf8')).join('\n\n---\n\n');
const SYSTEM = fs.readFileSync('system_prompt.md', 'utf8').replace('{{REGLAMENTO}}', () => CONOCIMIENTO);

// ---- Páginas: la raíz y /chat abren el chat de inmediato ----
const INDEX = path.resolve('public', 'index.html');
app.get(['/', '/chat'], (_, res) => res.sendFile(INDEX));
app.use(express.static('public', { index: false }));
app.get('/healthz', (_, res) => res.send('ok'));   // para el hosting y monitores

// ---- Límites: 20 mensajes/min por IP y tope diario global (protegen tu clave y tu costo) ----
const hits = new Map(); setInterval(() => hits.clear(), 60_000).unref();
let day = new Date().toDateString(), today = 0;
function overLimit(ip) {
  const d = new Date().toDateString(); if (d !== day) { day = d; today = 0; }
  const n = (hits.get(ip) || 0) + 1; hits.set(ip, n);
  return n > 20 ? 'minuto' : (++today > DAILY_LIMIT ? 'dia' : null);
}

app.post('/api/chat', async (req, res) => {
  const lim = overLimit(req.ip);
  if (lim === 'minuto') return res.status(429).json({ reply: 'Estás enviando muchos mensajes seguidos. Espera un minuto e intenta de nuevo.' });
  if (lim === 'dia') return res.status(429).json({ reply: 'Colbi alcanzó su límite de consultas de hoy. Intenta mañana o acude a la URCE o a la Dirección del Plantel 20.' });
  try {
    const messages = (Array.isArray(req.body.messages) ? req.body.messages : []).slice(-10)
      .map(m => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: String(m.content || '').slice(0, 1000) }));
    while (messages.length && messages[0].role !== 'user') messages.shift();
    if (!messages.length || messages[messages.length - 1].role !== 'user') return res.status(400).json({ reply: 'Escribe tu pregunta para comenzar.' });

    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({
        model: MODEL, max_tokens: 700, temperature: 0,
        system: [{ type: 'text', text: SYSTEM, cache_control: { type: 'ephemeral' } }],  // reutiliza el reglamento y abarata consultas
        messages
      })
    });
    if (!r.ok) throw new Error(await r.text());
    const data = await r.json();
    res.json({ reply: data.content.map(b => b.text || '').join('').trim() });
  } catch (e) {
    console.error(e);
    res.status(500).json({ reply: 'Tuve un problema técnico. Intenta de nuevo en un momento o acude a la URCE o a la Dirección del Plantel 20.' });
  }
});

// ---- Código QR (imagen real) apuntando a la URL pública del chat ----
// Prioridad: APP_URL -> RENDER_EXTERNAL_URL (la pone Render sola) -> dirección con la que abriste /qr
const publicUrl = (req) => {
  const base = [APP_URL, RENDER_EXTERNAL_URL].find(u => u && /^https?:\/\//i.test(u)) || `${req.protocol}://${req.get('host')}`;
  return base.replace(/\/+$/, '') + '/';
};
const px = (req) => Math.min(Math.max(parseInt(req.query.size) || 1000, 200), 3000);
app.get('/qr.png', async (req, res) => {
  if (req.query.download) res.attachment('qr-colbi.png');
  res.type('png').send(await QRCode.toBuffer(publicUrl(req), { width: px(req), margin: 3, errorCorrectionLevel: 'M' }));
});
app.get('/qr.svg', async (req, res) => {
  if (req.query.download) res.attachment('qr-colbi.svg');
  res.type('image/svg+xml').send(await QRCode.toString(publicUrl(req), { type: 'svg', margin: 3, errorCorrectionLevel: 'M' }));
});
app.get('/qr', (req, res) => {
  const url = publicUrl(req);
  const local = /localhost|127\.0\.0\.1|192\.168\.|10\.\d+\.|^http:\/\//.test(url);
  res.type('html').send(`<!doctype html><html lang="es"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>QR · Colbi</title><body style="font-family:system-ui;text-align:center;padding:24px;max-width:520px;margin:auto">
<h1>Colbi · COLBACH Plantel 20</h1><p>Escanea para consultar el reglamento</p>
<img src="/qr.png?size=800" width="320" height="320" alt="Código QR del chat de Colbi">
<p>Apunta a: <a href="${url}">${url}</a></p>
${local ? '<p style="background:#fff4d6;padding:10px;border-radius:8px"><b>Atención:</b> esta dirección es local o sin HTTPS y no funcionará fuera de tu red. Abre este mismo /qr desde tu URL pública (https://…).</p>' : ''}
<p><a href="/qr.png?size=2000&download=1"><b>Descargar PNG (qr-colbi.png)</b></a> · <a href="/qr.svg?download=1">Descargar SVG</a> · <a href="#" onclick="print();return false">Imprimir</a></p></body></html>`);
});

app.listen(PORT, '0.0.0.0', () => console.log(`Colbi listo en http://localhost:${PORT}  (QR en /qr)`));
