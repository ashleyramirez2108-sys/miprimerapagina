// Genera qr-colbi.png y qr-colbi.svg.
// Uso: npm run qr -- https://TU-URL-PUBLICA     (o define APP_URL en .env)
import 'dotenv/config';
import QRCode from 'qrcode';
const url = (process.argv[2] || process.env.APP_URL || '').trim().replace(/\/+$/, '');
if (!/^https:\/\//i.test(url)) { console.error('Indica la URL pública con https. Ejemplo:\n  npm run qr -- https://colbi-plantel20.onrender.com'); process.exit(1); }
await QRCode.toFile('qr-colbi.png', url + '/', { width: 2000, margin: 3, errorCorrectionLevel: 'M' });
await QRCode.toFile('qr-colbi.svg', url + '/', { type: 'svg', margin: 3, errorCorrectionLevel: 'M' });
console.log('Listo → qr-colbi.png y qr-colbi.svg apuntan a', url + '/');
